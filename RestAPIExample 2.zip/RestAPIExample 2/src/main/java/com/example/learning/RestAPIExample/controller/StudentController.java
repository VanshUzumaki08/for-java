package com.example.learning.RestAPIExample.controller;

import com.example.learning.RestAPIExample.dto.StudentDto;
import com.example.learning.RestAPIExample.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;

    @GetMapping("/students")
    public List<StudentDto> getStudents(){
        return studentService.getAllStudent();
    }

    @GetMapping("/students/{id}")
    public StudentDto getStudentsById(@PathVariable Long id){
        return studentService.getStudentById(id);
    }

}
