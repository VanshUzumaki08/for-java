package com.example.learning.RestAPIExample.service.impl;

import com.example.learning.RestAPIExample.dto.StudentDto;
import com.example.learning.RestAPIExample.entity.Student;
import com.example.learning.RestAPIExample.repository.StudentRepository;
import com.example.learning.RestAPIExample.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;

    @Override
    public List<StudentDto> getAllStudent() {
        return studentRepository.findAll().stream().map(student -> {
            return new StudentDto(student.getId(), student.getName(),student.getEmail());
        }).toList();
    }

    @Override
    public StudentDto getStudentById(Long id) {
        Student student = studentRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid id: "+ id));
        return new StudentDto(student.getId(), student.getName(),student.getEmail());
    }
}
