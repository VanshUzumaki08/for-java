package com.example.learning.RestAPIExample.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class StudentDto {
    private Long id;
    private String name;
    private String email;


}
