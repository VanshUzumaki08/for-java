package com.example.learning.RestAPIExample.service;

import com.example.learning.RestAPIExample.dto.StudentDto;
import org.springframework.stereotype.Service;

import java.util.List;

public interface StudentService {
    List<StudentDto> getAllStudent();

    StudentDto getStudentById(Long id);
}
