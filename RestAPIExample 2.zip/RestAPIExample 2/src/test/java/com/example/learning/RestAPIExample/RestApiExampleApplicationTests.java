package com.example.learning.RestAPIExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
