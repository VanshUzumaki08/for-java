package com.jpqldemo.jpqldemo.controller;

import com.jpqldemo.jpqldemo.entity.Patient;
import org.springframework.web.bind.annotation.*;
import com.jpqldemo.jpqldemo.repository.PatientRepository;

import java.util.List;

@RestController
@RequestMapping("/api/Patient")
public class PatientController {
    private final PatientRepository repository;

    public PatientController(PatientRepository repository) {
        this.repository = repository;
    }

    // Test API
    @GetMapping("/check")
    public String check() {
        return "JPQL API Working";
    }

    // Insert Data
    @PostMapping("/add")
    public String addPatient(@RequestBody Patient patient) {
        repository.save(patient);
        return "Patient added!";
    }

    // JPQL Query APІ
    @GetMapping("/above/{age}")
    public List<Patient> getPatientsAboveAge(@PathVariable int age) {
        return repository.findPatientsAboveAge(age);
    }
}
