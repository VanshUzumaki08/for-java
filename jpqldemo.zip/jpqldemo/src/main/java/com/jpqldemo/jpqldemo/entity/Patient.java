package com.jpqldemo.jpqldemo.entity;

import jakarta.persistence.*;
import lombok.Setter;

@Entity
@Table(name = "Patient")
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String name;
    @Setter
    private int age;

    public Patient(){}
public Patient(String name,int age)
{
    this.name=name;
    this.age=age;
}

public long getId(){return id;}
    public String getName(){return name;}
    public int getAge(){return age;}

    public void setName(String name){this.name=name;}
    public void setAge(int age){this.age=age;}
}
