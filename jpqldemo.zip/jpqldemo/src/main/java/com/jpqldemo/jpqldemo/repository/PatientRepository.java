package com.jpqldemo.jpqldemo.repository;
import com.jpqldemo.jpqldemo.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
public interface PatientRepository extends JpaRepository<Patient, Long>
{
    @Query("SELECT p FROM Patient p WHERE p.age > :age")
    List<Patient> findPatientsAboveAge(@Param("age") int age);


}