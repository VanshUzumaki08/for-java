package com.example.thymeleafsample.controller;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AuthController {

    @GetMapping("/login")
    public String login() {
        System.out.println(new BCryptPasswordEncoder().encode("123456"));
        return "login";
    }

    @GetMapping("/home")
    public String home() {
        return "home";
    }
}