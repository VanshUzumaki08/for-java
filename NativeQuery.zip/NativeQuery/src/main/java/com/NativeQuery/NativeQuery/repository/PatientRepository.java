package com.NativeQuery.NativeQuery.repository;

import com.NativeQuery.NativeQuery.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PatientRepository extends JpaRepository<Patient, Long> {
    // Native Query
    @Query(value = "SELECT * FROM patient WHERE age > :age", nativeQuery = true)
    List<Patient> findPatientsAboveAge (@Param("age") int age);}