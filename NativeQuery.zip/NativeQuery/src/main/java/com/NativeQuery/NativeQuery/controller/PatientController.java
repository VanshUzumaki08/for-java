package com.NativeQuery.NativeQuery.controller;

import com.NativeQuery.NativeQuery.entity.Patient;
import com.NativeQuery.NativeQuery.repository.PatientRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/patient")
public class PatientController {
    private final PatientRepository repository;

    public PatientController(PatientRepository repository) {
        this.repository = repository;

    }
    // Test API
    @GetMapping("/check")
    public String check() {
        return "Native Query API Working";
    }

    // Insert Data
    @PostMapping("/add")
    public String addPatient(@RequestBody Patient patient) {
        repository.save(patient);
        return "Patient added!";
    }

    // Native Query API
    @GetMapping("/above/{age}")
    public List<Patient> getPatientsAboveAge(@PathVariable int age) {
        return repository.findPatientsAboveAge(age);
    }
}