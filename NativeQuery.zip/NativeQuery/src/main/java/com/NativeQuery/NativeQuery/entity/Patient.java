package com.NativeQuery.NativeQuery.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Entity
@Table(name = "Patient")
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Setter
    private String name;
    @Setter
    private int age;
    public Patient() {}
    public Patient(String name, int age) {
        this.name = name;
        this.age= age;
    }

}

