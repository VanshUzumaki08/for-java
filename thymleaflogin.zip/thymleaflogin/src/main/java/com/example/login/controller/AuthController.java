package com.example.login.controller;

import com.example.login.model.User;
import com.example.login.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    // Home page - redirect to login
    @GetMapping("/")
    public String index() {
        return "redirect:/login";
    }

    // Show login form
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    // Handle login form submission
    @PostMapping("/login")
    public String login(@RequestParam String username, 
                       @RequestParam String password,
                       Model model) {
        
        // Find user by username
        Optional<User> user = userRepository.findByUsername(username);

        // Check if user exists and password matches
        if (user.isPresent() && user.get().getPassword().equals(password)) {
            // Login successful - send user to dashboard
            model.addAttribute("user", user.get());
            model.addAttribute("loggedIn", true);
            return "dashboard";
        } else {
            // Login failed - show error message
            model.addAttribute("error", "Invalid username or password");
            return "login";
        }
    }

    // Show registration form
    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    // Handle registration form submission
    @PostMapping("/register")
    public String register(@RequestParam String username,
                          @RequestParam String password,
                          @RequestParam String email,
                          @RequestParam String fullName,
                          Model model) {

        // Check if username already exists
        Optional<User> existingUser = userRepository.findByUsername(username);
        if (existingUser.isPresent()) {
            model.addAttribute("error", "Username already exists! Try another one.");
            return "register";
        }

        // Create new user and save to database
        User newUser = new User(username, password, email, fullName);
        userRepository.save(newUser);

        // Show success message and send to login
        model.addAttribute("success", "Registration successful! Now login with your username.");
        return "login";
    }

    // Handle logout
    @GetMapping("/logout")
    public String logout(RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("success", "Logged out successfully!");
        return "redirect:/login";
    }
}
