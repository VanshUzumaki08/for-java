package com.example.login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Main entry point of the application
@SpringBootApplication
public class ThymeleafLoginApplication {

    public static void main(String[] args) {
        // Start the Spring Boot application
        SpringApplication.run(ThymeleafLoginApplication.class, args);
    }
}
