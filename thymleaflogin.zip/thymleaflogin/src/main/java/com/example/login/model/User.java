package com.example.login.model;

import jakarta.persistence.*;

// User class - represents a user in the system
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;                    // Auto-generated ID

    @Column(nullable = false, unique = true)
    private String username;            // Username (must be unique)

    @Column(nullable = false)
    private String password;            // Password

    @Column(nullable = false)
    private String email;               // Email address

    @Column(name = "full_name")
    private String fullName;            // Full name of user

    // Empty constructor (required by JPA)
    public User() {
    }

    // Constructor with all fields
    public User(String username, String password, String email, String fullName) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.fullName = fullName;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}
