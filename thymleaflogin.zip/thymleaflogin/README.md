# Simple Thymeleaf Login Application

A beginner-friendly login and registration app built with **Spring Boot** and **Thymeleaf**.

## What This App Does

1. **Register** - Create a new user account
2. **Login** - Login with username and password
3. **Dashboard** - View your profile after login
4. **Logout** - Logout from the app

## Installation & Setup

### Step 1: Download & Open
- Open the folder: `c:\Users\Naresh\Downloads\java material\thymeleaflogin`
- Open this folder in VS Code or any Java IDE

### Step 2: Install Dependencies
Open the terminal and run:
```
mvn clean install
```

### Step 3: Run the App
```
mvn spring-boot:run
```

### Step 4: Open in Browser
- Go to: **http://localhost:8080**
- You will see the login page

## How to Use

### Creating an Account
1. Click "Create one here" on the login page
2. Fill in:
   - Full Name
   - Username (must be unique)
   - Email
   - Password
3. Click "Create Account"
4. You will be redirected to login

### Logging In
1. Enter your username
2. Enter your password
3. Click "Login"
4. You will see your dashboard

### View Your Profile
- On the dashboard, you can see:
  - Your name
  - Your username
  - Your email

### Logout
- Click the "Logout" button on the dashboard
- You will be logged out

## Project Folder Structure

```
thymeleaflogin/
├── pom.xml                          (Project configuration)
├── README.md                         (This file)
└── src/
    └── main/
        ├── java/com/example/login/
        │   ├── ThymeleafLoginApplication.java    (Starts the app)
        │   ├── controller/
        │   │   └── AuthController.java           (Handles login/register)
        │   ├── model/
        │   │   └── User.java                     (User data)
        │   └── repository/
        │       └── UserRepository.java           (Database access)
        └── resources/
            ├── templates/
            │   ├── login.html                    (Login page)
            │   ├── register.html                 (Registration page)
            │   └── dashboard.html                (User dashboard)
            ├── static/css/
            │   └── style.css                     (Styling)
            └── application.properties            (Settings)
```

## File Explanations

### Java Files (Backend)

**ThymeleafLoginApplication.java**
- Starts the entire application

**User.java**
- Represents a user in the system
- Has fields: id, username, password, email, fullName

**UserRepository.java**
- Handles database operations
- Stores and retrieves user data

**AuthController.java**
- Controls login/logout/register functionality
- Routes URLs to the right pages

### HTML Files (Pages)

**login.html**
- Login page where users enter username & password

**register.html**
- Page to create a new account

**dashboard.html**
- Page shown after successful login
- Displays user information

### CSS (Styling)

**style.css**
- Makes the pages look nice with colors and layout

## Technology Used

- **Java** - Programming language
- **Spring Boot** - Web framework
- **Thymeleaf** - Template engine (creates HTML pages)
- **H2 Database** - Database (stores user data)
- **Maven** - Build tool
- **HTML & CSS** - Frontend

## Important Notes

### Test User (Example)
You can create your own account, or:
- Username: `demo`
- Password: `demo123`
- Email: `demo@example.com`

### Database
- Uses H2 (in-memory database)
- Data is lost when you restart the app
- To keep data permanently, use MySQL or PostgreSQL

### Security
- Passwords are stored in plain text (not secure for real apps)
- For production apps, use proper encryption

## Common Issues & Solutions

**Issue: "Port 8080 is already in use"**
- Another app is using port 8080
- Kill that process or change port in `application.properties`

**Issue: "Dependency download errors"**
- Make sure Maven is installed
- Check internet connection

**Issue: "Page not found (404)"**
- Make sure the app is running
- Use correct URL: http://localhost:8080

## What to Learn From This

- How Spring Boot apps work
- How to handle form submissions
- How to validate user input
- How to store data in a database
- How to create HTML pages with Thymeleaf

## Next Steps (Advanced Features)

- Add email verification
- Add password reset
- Add user roles (admin/user)
- Use JWT for authentication
- Use MySQL database instead of H2
- Encrypt passwords

## Questions?

- Check the code comments
- Read the file structure
- Look at the HTML/CSS files

---

Happy Learning! 🎓

