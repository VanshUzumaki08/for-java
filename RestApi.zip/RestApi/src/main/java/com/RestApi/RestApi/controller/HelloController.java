package com.RestApi.RestApi.controller;



import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class HelloController {


    @GetMapping("/hello")
    public String hello() {
        return "Hello, REST API is working!";
    }


    @GetMapping("/welcome/{name}")
    public String welcome(@PathVariable String name) {
        return "Welcome, " + name + "!";
    }


    @PostMapping("/add")
    public String add(@RequestBody String data) {
        return "Received: " + data;
    }
}