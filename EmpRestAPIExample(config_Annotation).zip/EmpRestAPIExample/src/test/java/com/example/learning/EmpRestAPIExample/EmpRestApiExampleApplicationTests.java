package com.example.learning.EmpRestAPIExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpRestApiExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
