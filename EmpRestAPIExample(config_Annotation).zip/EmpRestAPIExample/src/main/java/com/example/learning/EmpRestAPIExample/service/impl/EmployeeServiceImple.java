package com.example.learning.EmpRestAPIExample.service.impl;

import com.example.learning.EmpRestAPIExample.dto.EmployeeDto;
import com.example.learning.EmpRestAPIExample.entity.Employee;
import com.example.learning.EmpRestAPIExample.repository.EmployeeRepository;
import com.example.learning.EmpRestAPIExample.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImple implements EmployeeService {
    private final EmployeeRepository employeeRepository;
    private final ModelMapper modelMapper;

    @Override
    public List<EmployeeDto> getAllEmployee() {
        return employeeRepository.findAll()
                .stream()
                .map(employee -> {
                    return modelMapper.map(employee, EmployeeDto.class);
                }).toList();
    }

    @Override
    public EmployeeDto createNewEmployee(EmployeeDto employeeDto) {
        Employee employee = modelMapper.map(employeeDto, Employee.class);
        Employee newEmployee = employeeRepository.save(employee);
        return modelMapper.map(newEmployee, EmployeeDto.class);
    }

    @Override
    public void deleteEmployeeById(Long id) {
        if(!employeeRepository.existsById(id)){
            throw  new IllegalArgumentException("Employee id not exist: " + id);
        }
        employeeRepository.deleteById(id);
    }

    @Override
    public EmployeeDto updateEmployee(Long id, EmployeeDto newEmployeeDto) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid id: "+ id));
        Long empId = employee.getEmpId();
        modelMapper.map(newEmployeeDto, employee);
        employee.setEmpId(empId);
        Employee newEmployee = employeeRepository.save(employee);
        return modelMapper.map(newEmployee, EmployeeDto.class);
    }

    @Override
    public EmployeeDto updateEmployeePatch(Long id, Map<String, Object> newEmployeeDto) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid id: "+ id));

        newEmployeeDto.forEach((key, value) -> {
            switch (key){
                case "empName": employee.setEmpName((String) value); break;
                case "empCity": employee.setEmpCity((String) value); break;
                default: throw new IllegalArgumentException("Invalid request keys");
            }
        });
        Employee newEmployee = employeeRepository.save(employee);
        return modelMapper.map(newEmployee, EmployeeDto.class);
    }
}
