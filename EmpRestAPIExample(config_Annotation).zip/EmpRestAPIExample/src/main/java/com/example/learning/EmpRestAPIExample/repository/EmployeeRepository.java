package com.example.learning.EmpRestAPIExample.repository;

import com.example.learning.EmpRestAPIExample.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}
