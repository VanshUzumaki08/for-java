package com.example.learning.EmpRestAPIExample.controller;

import com.example.learning.EmpRestAPIExample.dto.EmployeeDto;
import com.example.learning.EmpRestAPIExample.entity.Employee;
import com.example.learning.EmpRestAPIExample.service.EmployeeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    @GetMapping
    public ResponseEntity<List<EmployeeDto>> getAllEmployee(){
        return ResponseEntity.ok(employeeService.getAllEmployee());
    }

    @PostMapping
    public ResponseEntity<EmployeeDto> addNewEmployee(@RequestBody EmployeeDto employeeDto){
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(employeeService.createNewEmployee(employeeDto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
        employeeService.deleteEmployeeById(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("{id}")
    public ResponseEntity<EmployeeDto> addNewStudent(@PathVariable Long id, @RequestBody @Valid EmployeeDto newEmployeeDto){
        return ResponseEntity.ok(employeeService.updateEmployee(id, newEmployeeDto));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<EmployeeDto>updateStudent(@PathVariable Long id, @RequestBody Map<String, Object> newEmployeeDto){
        return ResponseEntity.ok(employeeService.updateEmployeePatch(id, newEmployeeDto));
    }

}
