package com.example.learning.EmpRestAPIExample.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class EmployeeDto {
    private Long empId;

    @NotBlank(message = "Employee name should not blank")
    @Size(min = 3, max = 20, message = "Name is in range [2,30]")
    private String empName;

    @NotBlank(message = "Employee name should not blank")
    @Size(min = 3, max = 12, message = "Name is in range [2,12]")
    private String empCity;
}
