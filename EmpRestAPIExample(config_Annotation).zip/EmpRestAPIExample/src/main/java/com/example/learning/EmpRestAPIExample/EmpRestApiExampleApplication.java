package com.example.learning.EmpRestAPIExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpRestApiExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpRestApiExampleApplication.class, args);
	}

}
