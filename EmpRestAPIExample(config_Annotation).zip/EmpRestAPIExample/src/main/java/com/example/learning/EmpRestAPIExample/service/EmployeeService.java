package com.example.learning.EmpRestAPIExample.service;

import com.example.learning.EmpRestAPIExample.dto.EmployeeDto;
import jakarta.validation.Valid;

import java.util.List;
import java.util.Map;

public interface EmployeeService {
    List<EmployeeDto> getAllEmployee();

    EmployeeDto createNewEmployee(EmployeeDto employeeDto);

    void deleteEmployeeById(Long id);

    EmployeeDto updateEmployee(Long id, @Valid EmployeeDto newEmployeeDto);

    EmployeeDto updateEmployeePatch(Long id, Map<String, Object> newEmployeeDto);
}
