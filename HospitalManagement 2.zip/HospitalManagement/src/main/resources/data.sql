insert into patient(`name`, `birth_date`, `email`, `blood_group`)
values ('Vishal','1990-05-23', 'vishal.patel@gmail.com','B_POSITIVE'),
       ('Rahul','1990-07-23', 'vishal.d@droisys.com','O_POSITIVE'),
       ('Raj','2003-02-28', 'abc.d@gmail.com','O_POSITIVE'),
       ('Darshan','1992-07-23', 'qwerty.d@droisys.com','AB_NEGATIVE'),
       ('Nil','2000-01-12', 'nil.m@gmail.com','AB_NEGATIVE');
